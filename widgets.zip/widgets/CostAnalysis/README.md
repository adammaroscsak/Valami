Cost analysis WAB widget
