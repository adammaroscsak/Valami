// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define(["dojo/_base/declare","./settingComponents","./SettingObject"],function(b,c,a){return b(a,{constructor:function(b,a){this._mainDiv=c.container(null,null,a)}})});