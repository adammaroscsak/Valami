// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Podeli",selectSocialNetwork:"Izaberi slede\u0107e opcije za deljenje aplikacije:",email:"E-mail",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Dodaj novi",socialMediaUrl:"URL adresa va\u0161ih dru\u0161tvenih medija",uploadIcon:"Otpremi ikonu",embedAppInWebsite:"Ugradi aplikaciju u veb sajt",_localized:{}}});