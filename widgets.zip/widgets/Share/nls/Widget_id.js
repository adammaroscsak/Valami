// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Bagikan",selectSocialNetwork:"Pilih opsi berikut untuk berbagi aplikasi ini:",email:"Email",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Tambah baru",socialMediaUrl:"URL media sosial Anda",uploadIcon:"Unggah ikon",embedAppInWebsite:"Tempelkan aplikasi pada situs web",_localized:{}}});