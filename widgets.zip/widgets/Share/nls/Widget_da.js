// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Del",selectSocialNetwork:"V\u00e6lg f\u00f8lgende indstillinger for at dele app'en:",email:"E-mail",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Tilf\u00f8j nyt",socialMediaUrl:"URL til dine sociale medier",uploadIcon:"Overf\u00f8r ikon",embedAppInWebsite:"Indlejr app'en i webstedet",_localized:{}}});