// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Condividi",selectSocialNetwork:"Selezionare le seguenti opzioni per condividere l'app:",email:"E-mail",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Aggiungi nuovo",socialMediaUrl:"URL del social media",uploadIcon:"Icona Carica",embedAppInWebsite:"Incorpora l'app in un sito Web",_localized:{}}});