// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Jaga",selectSocialNetwork:"Valige rakenduse jagamiseks j\u00e4rgmised valikud:",email:"E-post",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Lisa uus",socialMediaUrl:"Teie\u00a0sotsiaalmeedia\u00a0URL",uploadIcon:"Laadi ikoon",embedAppInWebsite:"Manusta rakendus veebisaidile",_localized:{}}});