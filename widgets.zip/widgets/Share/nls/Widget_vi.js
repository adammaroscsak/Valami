// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Chia s\u1ebb",selectSocialNetwork:"Ch\u1ecdn c\u00e1c t\u00f9y ch\u1ecdn sau \u0111\u1ec3 chia s\u1ebb \u1ee9ng d\u1ee5ng:",email:"Email",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Th\u00eam m\u1edbi",socialMediaUrl:"URL ph\u01b0\u01a1ng ti\u1ec7n truy\u1ec1n th\u00f4ng x\u00e3 h\u1ed9i c\u1ee7a b\u1ea1n",uploadIcon:"Bi\u1ec3u t\u01b0\u1ee3ng t\u1ea3i l\u00ean",embedAppInWebsite:"Nh\u00fang \u1ee9ng d\u1ee5ng v\u00e0o trang web",
_localized:{}}});