// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Dele",selectSocialNetwork:"Velg f\u00f8lgende alternativer for \u00e5 dele appen:",email:"E-post",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Legg til ny",socialMediaUrl:"URL til dine sosiale medier",uploadIcon:"Last opp ikon",embedAppInWebsite:"Bygg inn appen p\u00e5 webomr\u00e5det",_localized:{}}});