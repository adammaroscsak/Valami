// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Delen",selectSocialNetwork:"Selecteer de volgende opties om de app te delen:",email:"E-mail",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Nieuwe toevoegen",socialMediaUrl:"Uw social media URL",uploadIcon:"Pictogram uploaden",embedAppInWebsite:"App inbedden in website",_localized:{}}});