// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Megoszt\u00e1s",selectSocialNetwork:"Az alkalmaz\u00e1s megoszt\u00e1s\u00e1hoz v\u00e1lasszon a k\u00f6vetkez\u0151 lehet\u0151s\u00e9gek k\u00f6z\u00fcl:",email:"E-mail",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"\u00daj hozz\u00e1ad\u00e1sa",socialMediaUrl:"Saj\u00e1t k\u00f6z\u00f6ss\u00e9gi m\u00e9dia URL-c\u00edme",uploadIcon:"Ikon felt\u00f6lt\u00e9se",embedAppInWebsite:"Alkalmaz\u00e1s be\u00e1gyaz\u00e1sa webhelyen",
_localized:{}}});