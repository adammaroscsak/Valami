// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Share",selectSocialNetwork:"Select following options to share the app:",email:"Email",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Add new",socialMediaUrl:"Your social media URL",uploadIcon:"Upload icon",embedAppInWebsite:"Embed the app in website",_localized:{}}});