// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/Share/nls/strings":{_widgetLabel:"Podijeli",selectSocialNetwork:"Odaberite slijede\u0107e opcije za dijeljenje appa:",email:"E-po\u0161ta",facebook:"Facebook",googlePlus:"Google+",twitter:"Twitter",addNew:"Dodaj novi",socialMediaUrl:"URL dru\u0161tvenog medija",uploadIcon:"U\u010ditaj ikonu",embedAppInWebsite:"Ugradi app na web-mjesto",_localized:{}}});