// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/HomeButton/nls/strings":{_widgetLabel:"\u0391\u03c1\u03c7\u03b9\u03ba\u03ae",_localized:{}}});