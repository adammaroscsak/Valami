// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/HomeButton/nls/strings":{_widgetLabel:"\u0e2b\u0e19\u0e49\u0e32\u0e2b\u0e25\u0e31\u0e01",_localized:{}}});