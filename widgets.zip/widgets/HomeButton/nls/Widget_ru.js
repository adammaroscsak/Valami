// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"widgets/HomeButton/nls/strings":{_widgetLabel:"\u041d\u0430 \u0433\u043b\u0430\u0432\u043d\u0443\u044e",_localized:{}}});